import { useEffect, useRef, useState } from 'react';
import { TABS, allSectionsText, seoStats, wordCount } from '../lib/format.js';
import { copyText } from '../lib/clipboard.js';

function Editor({ value, onChange, label }) {
  const ref = useRef(null);
  // Grow the box to fit the text so the page scrolls instead of the box.
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight + 4}px`;
  }, [value]);

  return (
    <textarea
      ref={ref}
      className="editor"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label={label}
      spellCheck="true"
    />
  );
}

export default function Results({ result, onRegenerate, onEditDetails, busy }) {
  const original = result.sections;
  const [sections, setSections] = useState(original);
  const [active, setActive] = useState('home');
  const [copied, setCopied] = useState('');
  const [toast, setToast] = useState('');
  const timers = useRef({});

  useEffect(() => () => Object.values(timers.current).forEach(clearTimeout), []);

  const flash = (id, message) => {
    setCopied(id);
    setToast(message);
    clearTimeout(timers.current.copied);
    timers.current.copied = setTimeout(() => { setCopied(''); setToast(''); }, 1800);
  };

  async function handleCopy(id, text, message) {
    const ok = await copyText(text);
    if (ok) flash(id, message);
    else { setToast('Copy failed. Select the text and press Ctrl/Cmd + C.'); clearTimeout(timers.current.copied); timers.current.copied = setTimeout(() => setToast(''), 3000); }
  }

  const activeTab = TABS.find((t) => t.id === active);
  const edited = sections[active] !== original[active];
  const isDemo = result.source === 'demo';

  function onTabKey(e) {
    const idx = TABS.findIndex((t) => t.id === active);
    let next = null;
    if (e.key === 'ArrowRight') next = TABS[(idx + 1) % TABS.length];
    if (e.key === 'ArrowLeft') next = TABS[(idx - 1 + TABS.length) % TABS.length];
    if (next) {
      e.preventDefault();
      setActive(next.id);
      document.getElementById(`tab-${next.id}`)?.focus();
    }
  }

  const stats = active === 'seo' ? seoStats(sections.seo) : null;

  return (
    <div className="container">
      <div className="results-head">
        <div>
          <h2>Your website copy</h2>
          {isDemo ? (
            <span className="badge badge-demo">Demo content · not written by AI</span>
          ) : (
            <span className="badge badge-ai">Written by Claude{result.model ? ` · ${result.model}` : ''}</span>
          )}
        </div>
        <div className="results-actions">
          <button className="btn btn-primary" onClick={() => handleCopy('all', allSectionsText(sections), 'All sections copied')}>
            {copied === 'all' ? 'Copied!' : 'Copy All'}
          </button>
          <button className="btn btn-ghost" onClick={onRegenerate} disabled={busy}>Regenerate</button>
          <button className="btn btn-link" onClick={onEditDetails}>Edit details</button>
        </div>
      </div>

      {isDemo && (
        <div className="banner banner-demo">
          This is sample output built from your answers with a template. Add an API key in <code>server/.env</code> to get real AI-written copy.
        </div>
      )}

      <div className="card dashboard">
        <div className="tabs" role="tablist" aria-label="Website sections" onKeyDown={onTabKey}>
          {TABS.map((t) => (
            <button
              key={t.id}
              id={`tab-${t.id}`}
              role="tab"
              aria-selected={active === t.id}
              aria-controls={`panel-${t.id}`}
              tabIndex={active === t.id ? 0 : -1}
              className={`tab${active === t.id ? ' active' : ''}`}
              onClick={() => setActive(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="panel" role="tabpanel" id={`panel-${active}`} aria-labelledby={`tab-${active}`} key={active}>
          <div className="panel-bar">
            <h3>{activeTab.title}</h3>
            <div className="panel-actions">
              <button className="btn btn-ghost btn-sm" onClick={() => setSections((s) => ({ ...s, [active]: original[active] }))} disabled={!edited}>
                Reset edits
              </button>
              <button className="btn btn-primary btn-sm" onClick={() => handleCopy(active, sections[active], `${activeTab.title} copied`)}>
                {copied === active ? 'Copied!' : 'Copy'}
              </button>
            </div>
          </div>

          <Editor
            value={sections[active]}
            onChange={(v) => setSections((s) => ({ ...s, [active]: v }))}
            label={`${activeTab.title} text. You can edit it.`}
          />

          <div className="panel-foot">
            <span>{wordCount(sections[active])} words · click the text to edit it</span>
            {stats && (
              <span className="seo-stats">
                <span className={stats.titleLen > 60 ? 'warn' : 'ok'}>Title {stats.titleLen}/60</span>
                <span className={stats.descLen > 160 ? 'warn' : 'ok'}>Description {stats.descLen}/160</span>
              </span>
            )}
          </div>
        </div>
      </div>

      <div className={`toast${toast ? ' show' : ''}`} role="status" aria-live="polite">{toast}</div>
    </div>
  );
}
