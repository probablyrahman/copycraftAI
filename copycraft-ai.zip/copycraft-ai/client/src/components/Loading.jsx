import { useEffect, useState } from 'react';

const STEPS = [
  'Reading your business details…',
  'Shaping your brand voice…',
  'Writing your Home and About pages…',
  'Drafting services and FAQs…',
  'Polishing your SEO metadata…',
];

export default function Loading() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((n) => Math.min(n + 1, STEPS.length - 1)), 2600);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="container narrow">
      <div className="card loading" role="status" aria-live="polite">
        <div className="orbit" aria-hidden="true"><span /><span /><span /></div>
        <h3>Crafting your copy</h3>
        <p className="loading-step" key={i}>{STEPS[i]}</p>
        <div className="skeleton" aria-hidden="true">
          <i className="w90" /><i className="w70" /><i className="w80" /><i className="w50" />
        </div>
      </div>
    </div>
  );
}
