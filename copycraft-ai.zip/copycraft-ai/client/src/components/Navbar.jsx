import Logo from './Logo.jsx';

export default function Navbar({ status, onStart }) {
  let pill = null;
  if (status.loaded) {
    if (status.offline) pill = <span className="pill-status pill-bad">Backend offline</span>;
    else if (status.aiAvailable) pill = <span className="pill-status pill-live"><i /> Live AI</span>;
    else pill = <span className="pill-status pill-demo"><i /> Demo mode</span>;
  }

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <a className="brand" href="#top" aria-label="CopyCraft AI home">
          <Logo />
          <span>CopyCraft AI</span>
        </a>
        <div className="nav-right">
          {pill}
          <button className="btn btn-ghost btn-sm" onClick={onStart}>Start Creating</button>
        </div>
      </div>
    </header>
  );
}
