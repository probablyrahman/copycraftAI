export default function Hero({ onStart }) {
  return (
    <section className="hero" id="top">
      <div className="container hero-grid">
        <div className="hero-copy">
          <h1>Your Website. Your Story. Written by AI.</h1>
          <p className="hero-sub">Generate compelling website copy for your business in seconds.</p>
          <div className="hero-actions">
            <button className="btn btn-primary btn-lg" onClick={onStart}>Start Creating</button>
            <span className="hero-note">Home, About, Services, FAQs and SEO in one go.</span>
          </div>
        </div>

        <div className="sample" aria-hidden="true">
          <div className="sample-label">Example of what you get</div>
          <div className="sample-tabs">
            <span className="on">Home</span><span>About</span><span>Services</span><span>FAQs</span><span>SEO</span>
          </div>
          <div className="sample-body">
            <p className="sample-h">Freshly roasted, delivered to your door</p>
            <p>Small-batch coffee from farms we know by name, roasted the week you order it.</p>
            <p className="sample-line w80" />
            <p className="sample-line w60" />
            <span className="sample-cta">Order your first bag</span>
          </div>
        </div>
      </div>
    </section>
  );
}
