import { TONES } from '../lib/validate.js';

function Field({ id, label, hint, error, full, children }) {
  return (
    <div className={`field${full ? ' full' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {error ? (
        <p className="error" id={`${id}-error`} role="alert">{error}</p>
      ) : (
        hint && <p className="hint" id={`${id}-hint`}>{hint}</p>
      )}
    </div>
  );
}

function ModeBanner({ status }) {
  if (!status.loaded) return null;
  if (status.offline) {
    return (
      <div className="banner banner-bad" role="status">
        We can't reach the backend server. Start the project with <code>npm run dev</code> and refresh this page.
      </div>
    );
  }
  if (!status.aiAvailable) {
    return (
      <div className="banner banner-demo" role="status">
        <strong>Demo mode.</strong> No API key was found, so you'll get sample content that is clearly marked as demo output (not written by AI).
      </div>
    );
  }
  return (
    <div className="banner banner-live" role="status">
      <strong>Live AI connected.</strong> Your content will be written by Claude.
    </div>
  );
}

export default function InputForm({ form, setForm, errors, onSubmit, onFillExample, onClear, busy, status }) {
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const props = (key) => ({
    id: key,
    value: form[key],
    onChange: set(key),
    'aria-invalid': errors[key] ? 'true' : 'false',
    'aria-describedby': errors[key] ? `${key}-error` : `${key}-hint`,
  });

  return (
    <section id="create" className="section">
      <div className="container narrow">
        <div className="section-head">
          <h2>Tell us about your business</h2>
          <p>The more specific you are, the better your copy will be.</p>
        </div>

        <ModeBanner status={status} />

        <form className="card form" onSubmit={onSubmit} noValidate>
          <div className="form-grid">
            <Field id="businessName" label="Business name" error={errors.businessName}>
              <input type="text" placeholder="e.g. Ember & Oak Coffee" maxLength={100} {...props('businessName')} />
            </Field>

            <Field id="industry" label="Industry" error={errors.industry}>
              <input type="text" list="industry-list" placeholder="e.g. Specialty coffee roaster" maxLength={100} {...props('industry')} />
              <datalist id="industry-list">
                {['Restaurant or cafe', 'E-commerce', 'Health and wellness', 'Real estate', 'Legal services', 'Education', 'Technology / SaaS', 'Consulting', 'Fitness', 'Creative agency'].map((i) => (
                  <option key={i} value={i} />
                ))}
              </datalist>
            </Field>

            <Field id="description" label="Business description" full error={errors.description} hint="What do you do, and what makes you different?">
              <textarea rows={4} placeholder="Tell us what your business does, your story, and what customers love about you." maxLength={1500} {...props('description')} />
            </Field>

            <Field id="audience" label="Target audience" error={errors.audience} hint="Who are your ideal customers?">
              <input type="text" placeholder="e.g. Remote workers and local offices" maxLength={400} {...props('audience')} />
            </Field>

            <Field id="services" label="Products or services" error={errors.services} hint="Separate each one with a comma.">
              <input type="text" placeholder="e.g. Coffee beans, Subscriptions, Workshops" maxLength={800} {...props('services')} />
            </Field>

            <div className="field full">
              <span className="label" id="tone-label">Writing tone</span>
              <div className="tones" role="radiogroup" aria-labelledby="tone-label">
                {TONES.map((t) => (
                  <label className="tone" key={t}>
                    <input
                      type="radio"
                      name="tone"
                      value={t}
                      checked={form.tone === t}
                      onChange={() => setForm((f) => ({ ...f, tone: t }))}
                    />
                    <span>{t}</span>
                  </label>
                ))}
              </div>
            </div>

            <Field id="keywords" label="Target SEO keywords" error={errors.keywords} hint="Words people might search for. Separate with commas.">
              <input type="text" placeholder="e.g. fresh roasted coffee, coffee subscription" maxLength={300} {...props('keywords')} />
            </Field>

            <Field id="cta" label="Call to action" error={errors.cta} hint="What should visitors do next?">
              <input type="text" placeholder="e.g. Order your first bag" maxLength={100} {...props('cta')} />
            </Field>
          </div>

          <div className="form-actions">
            <button type="submit" className="btn btn-primary btn-lg" disabled={busy}>
              {busy ? 'Generating…' : 'Generate Website Copy'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onFillExample} disabled={busy}>Fill with example</button>
            <button type="button" className="btn btn-link" onClick={onClear} disabled={busy}>Clear form</button>
          </div>
        </form>
      </div>
    </section>
  );
}
