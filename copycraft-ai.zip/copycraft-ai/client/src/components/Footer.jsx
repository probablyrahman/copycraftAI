import Logo from './Logo.jsx';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="brand">
          <Logo size={26} />
          <span>CopyCraft AI</span>
        </div>
        <p>Website copy, written in seconds. Built for the hackathon with React, Express and Claude.</p>
        <p className="footer-small">© {new Date().getFullYear()} CopyCraft AI</p>
      </div>
    </footer>
  );
}
