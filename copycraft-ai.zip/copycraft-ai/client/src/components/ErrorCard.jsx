export default function ErrorCard({ message, onRetry, onDemo, canRetry }) {
  return (
    <div className="container narrow">
      <div className="card error-card" role="alert">
        <h3>We couldn't generate your copy</h3>
        <p>{message}</p>
        <div className="form-actions">
          {canRetry && <button className="btn btn-primary" onClick={onRetry}>Try again</button>}
          <button className="btn btn-ghost" onClick={onDemo}>Use demo content instead</button>
        </div>
      </div>
    </div>
  );
}
