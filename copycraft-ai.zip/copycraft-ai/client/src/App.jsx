import { useEffect, useRef, useState } from 'react';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import InputForm from './components/InputForm.jsx';
import Loading from './components/Loading.jsx';
import Results from './components/Results.jsx';
import ErrorCard from './components/ErrorCard.jsx';
import Footer from './components/Footer.jsx';
import { contentToSections } from './lib/format.js';
import { validateForm, EMPTY_FORM, EXAMPLE_FORM, FIELD_ORDER } from './lib/validate.js';

export default function App() {
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ loaded: false, aiAvailable: false, offline: false });
  const [phase, setPhase] = useState('idle'); // idle | loading | done | error
  const [result, setResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const lastRequest = useRef(null);
  const resultsRef = useRef(null);

  // Ask the server whether a real API key is configured.
  useEffect(() => {
    fetch('/api/status')
      .then((r) => r.json())
      .then((d) => setStatus({ loaded: true, offline: false, ...d }))
      .catch(() => setStatus({ loaded: true, offline: true, aiAvailable: false }));
  }, []);

  // Scroll to the results area whenever we start loading or finish.
  useEffect(() => {
    if (phase !== 'idle') resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [phase]);

  function scrollToForm() {
    document.getElementById('create')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => document.getElementById('businessName')?.focus({ preventScroll: true }), 500);
  }

  async function generate(input, useDemo = false) {
    lastRequest.current = { input, useDemo };
    setPhase('loading');
    setErrorMsg('');
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, useDemo }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
      setResult({
        source: data.source,
        model: data.model,
        sections: contentToSections(data.content),
        id: Date.now(), // a new id resets the editable text
      });
      setPhase('done');
    } catch (err) {
      const offline = err instanceof TypeError;
      setErrorMsg(
        offline
          ? "We couldn't reach the server. Make sure it is running (npm run dev) and try again."
          : err.message
      );
      setPhase('error');
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    const found = validateForm(form);
    setErrors(found);
    const firstBad = FIELD_ORDER.find((k) => found[k]);
    if (firstBad) {
      document.getElementById(firstBad)?.focus();
      return;
    }
    const trimmed = Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim()]));
    generate(trimmed);
  }

  function handleRegenerate() {
    if (lastRequest.current) generate(lastRequest.current.input, lastRequest.current.useDemo);
  }

  function handleUseDemo() {
    if (lastRequest.current) generate(lastRequest.current.input, true);
  }

  function handleFillExample() {
    setForm(EXAMPLE_FORM);
    setErrors({});
  }

  function handleClear() {
    setForm(EMPTY_FORM);
    setErrors({});
  }

  return (
    <>
      <div className="bg-glow" aria-hidden="true" />
      <Navbar status={status} onStart={scrollToForm} />
      <main>
        <Hero onStart={scrollToForm} />
        <InputForm
          form={form}
          setForm={setForm}
          errors={errors}
          onSubmit={handleSubmit}
          onFillExample={handleFillExample}
          onClear={handleClear}
          busy={phase === 'loading'}
          status={status}
        />
        <div ref={resultsRef} className="results-anchor">
          {phase === 'loading' && <Loading />}
          {phase === 'error' && (
            <ErrorCard message={errorMsg} onRetry={handleRegenerate} onDemo={handleUseDemo} canRetry={!!lastRequest.current} />
          )}
          {phase === 'done' && result && (
            <Results
              key={result.id}
              result={result}
              onRegenerate={handleRegenerate}
              onEditDetails={scrollToForm}
              busy={false}
            />
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
