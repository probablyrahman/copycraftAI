# CopyCraft AI

**Your Website. Your Story. Written by AI.**

Type in your business details and instantly get website copy for the Home page, About page, Services page, FAQs and SEO metadata. You can edit the text, copy each section, copy everything at once, or regenerate.

No database. No account system. Just a website (React) and a small server (Node/Express) that talks to Claude.

---

## What you need (one time)

1. **Node.js version 18 or newer.** Download the "LTS" version from https://nodejs.org and install it.
   To check it worked, open a terminal and type `node -v`. You should see a number like `v20.11.0`.
2. **An Anthropic API key** (optional). Without one, the app still works in **Demo mode**.

## Run it in 4 steps

Open a terminal **inside the `copycraft-ai` folder** (the one that contains this README).

**Step 1 - Install everything**
```
npm run setup
```
This downloads the tools the project needs. It takes a minute or two.

**Step 2 - Add your API key (skip this for Demo mode)**
1. Go into the `server` folder.
2. Make a copy of the file `.env.example` and name the copy `.env`
   (on Mac/Linux: `cp server/.env.example server/.env`).
3. Open `.env` in any text editor and paste your key after `ANTHROPIC_API_KEY=`
   Example: `ANTHROPIC_API_KEY=sk-ant-xxxxxxxx`

**Step 3 - Start the app**
```
npm run dev
```

**Step 4 - Open it**
Go to **http://localhost:5173** in your browser.

Press `Ctrl + C` in the terminal to stop the app.

---

## Demo mode vs Live AI

Look at the small badge in the top-right of the page:

| Badge | Meaning |
|---|---|
| **Live AI** (green) | Your API key works. Content is written by Claude. |
| **Demo mode** (yellow) | No key found. You get sample content built from a template. It is clearly labeled **"Demo content - not written by AI"**. |
| **Backend offline** (red) | The server isn't running. Run `npm run dev` again. |

If the AI ever fails during a live demo (bad Wi-Fi, usage limit), the error message has a **"Use demo content instead"** button so you can keep presenting.

## Handy demo tip

Click **"Fill with example"** in the form to fill every field instantly, then click **Generate Website Copy**.

## How it works (plain English)

1. You fill in the form in your browser.
2. The browser sends your answers to **your own server** (`/api/generate`).
3. The server adds your answers to instructions for Claude and sends them to the Anthropic API. **Your API key only exists on the server**, never in the website code visitors can see.
4. Claude replies, the server double-checks the reply, and the website shows it in tabs.

## Project map

```
copycraft-ai/
├── package.json          Shortcuts: npm run setup / dev / build / start
├── server/
│   ├── index.js          The server: validation, Claude call, demo fallback
│   ├── demo.js           Builds the sample "demo mode" content
│   └── .env.example      Copy to .env and add your API key
└── client/
    ├── index.html
    └── src/
        ├── App.jsx           Main page logic (form -> loading -> results)
        ├── styles.css        All the colors, layout and animations
        ├── components/       Navbar, Hero, InputForm, Loading, Results, ErrorCard, Footer
        └── lib/              Validation, text formatting, copy-to-clipboard
```

## Troubleshooting

- **"npm is not recognized"** - Install Node.js (see above), then close and reopen your terminal.
- **The page says "Backend offline"** - Make sure the terminal running `npm run dev` is still open and shows no red errors.
- **"The API key was rejected"** - Re-copy the key into `server/.env`, make sure there are no spaces or quotes, then stop (`Ctrl + C`) and run `npm run dev` again. The server only reads `.env` when it starts.
- **"Model not found"** - Add `ANTHROPIC_MODEL=` followed by a model name available to your account in `server/.env`.
- **Port already in use** - Close other programs using ports 3001 or 5173, or restart your computer.

## Putting it online (optional)

`npm start` builds the website and serves everything from one server on port 3001. Hosting services such as Render or Railway can run it: set the build command to `npm run setup && npm run build`, the start command to `npm start --prefix server`, and add `ANTHROPIC_API_KEY` in the host's environment-variable settings (never commit your `.env` file).

## Settings you can change (server/.env)

| Setting | What it does | Default |
|---|---|---|
| `ANTHROPIC_API_KEY` | Your key. Empty = Demo mode | empty |
| `ANTHROPIC_MODEL` | Which Claude model to use | `claude-sonnet-5-5` |
| `PORT` | Server port | `3001` |
| `RATE_LIMIT_MAX` | Max AI requests per visitor per 10 minutes | `30` |
