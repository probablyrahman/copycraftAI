// Demo content builder.
// Used when no API key is set (or when the user chooses "demo content").
// It is NOT written by AI - it reuses the user's own details inside a template,
// and the app labels it clearly as demo output.

const list = (text) =>
  String(text || '')
    .split(/[,\n;]+/)
    .map((s) => s.trim())
    .filter(Boolean);

const slugify = (text) =>
  String(text || 'my-business')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'my-business';

const trimTo = (text, max) => (text.length <= max ? text : text.slice(0, max - 1).trimEnd() + '…');

const TONE_STYLE = {
  Professional: {
    headline: (n) => `${n}: Trusted expertise you can rely on`,
    intro: 'We combine proven experience with a careful, results-focused approach.',
    cta: (c) => c,
  },
  Friendly: {
    headline: (n) => `Welcome to ${n} - we're glad you're here!`,
    intro: "We're a team that loves what we do, and we'd love to help you too.",
    cta: (c) => `${c} - we can't wait to meet you!`,
  },
  Persuasive: {
    headline: (n) => `Stop settling. Start winning with ${n}.`,
    intro: 'Customers who choose us never look back. Here is why you will not either.',
    cta: (c) => `${c} today - your competitors already are.`,
  },
  Minimal: {
    headline: (n) => `${n}. Done well.`,
    intro: 'Simple. Clear. Effective.',
    cta: (c) => c,
  },
  Playful: {
    headline: (n) => `Hey there! Meet ${n} 🎉`,
    intro: "We take our work seriously, just not ourselves. Let's have some fun with this.",
    cta: (c) => `${c} - it'll be a good time, promise!`,
  },
};

export function buildDemoContent(input) {
  const name = input.businessName;
  const industry = input.industry;
  const audience = input.audience;
  const tone = TONE_STYLE[input.tone] ? input.tone : 'Professional';
  const style = TONE_STYLE[tone];
  const services = list(input.services).slice(0, 6);
  const keywords = list(input.keywords).slice(0, 8);
  const mainKeyword = keywords[0] || industry;
  const cta = style.cta(input.cta);

  const home = {
    headline: style.headline(name),
    subheadline: `${industry} built around ${audience}.`,
    intro: `${style.intro} ${input.description}`,
    highlights: [
      { title: 'Made for you', text: `Everything we do at ${name} starts with what ${audience} actually need.` },
      { title: 'Clear and honest', text: 'You always know what you are getting, what it costs, and what happens next.' },
      { title: 'Real results', text: 'We measure success by the difference we make for the people we serve.' },
    ],
    cta,
  };

  const about = {
    headline: `About ${name}`,
    story: `${name} started with a simple idea: ${industry.toLowerCase()} should work better for the people who rely on it. ${input.description}`,
    mission: `Our mission is to give ${audience} a better experience, every single time.`,
    values: [
      { title: 'Quality first', text: 'We would rather do fewer things well than many things halfway.' },
      { title: 'People matter', text: 'Behind every order or enquiry is a real person, and we treat them that way.' },
      { title: 'Always improving', text: 'We listen, learn, and keep getting better.' },
    ],
  };

  const servicesBlock = {
    headline: `What ${name} offers`,
    intro: `Here is how we help ${audience}.`,
    services: services.map((s) => ({
      name: s,
      description: `${s} from ${name}, designed around what ${audience} care about most.`,
    })),
    cta,
  };

  const faqs = [
    { question: `What does ${name} do?`, answer: `${name} provides ${services.slice(0, 3).join(', ') || industry.toLowerCase()} for ${audience}.` },
    { question: `Who is ${name} for?`, answer: `Our work is designed for ${audience}, though anyone is welcome to get in touch.` },
    { question: 'How do I get started?', answer: `It's easy. ${input.cta} and we'll guide you through the next steps.` },
    { question: 'How much does it cost?', answer: 'Pricing depends on your needs. Contact us for a clear, no-surprise quote.' },
    { question: 'How long does it take?', answer: 'Timelines vary by project. We will give you a realistic estimate before we begin.' },
    { question: 'Can I change my mind or ask for adjustments?', answer: 'Of course. We want you to be happy, so we are always open to feedback and changes.' },
  ];

  const seo = {
    title: trimTo(`${name} | ${mainKeyword}`, 60),
    metaDescription: trimTo(
      `${name} offers ${services.slice(0, 2).join(' and ') || industry.toLowerCase()} for ${audience}. ${input.cta}.`,
      158
    ),
    keywords: keywords.length ? keywords : [industry.toLowerCase(), name.toLowerCase()],
    slug: slugify(name),
  };

  return { home, about, services: servicesBlock, faqs, seo };
}
